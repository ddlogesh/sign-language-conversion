# dependencies
# pip install --upgrade "watson-developer-cloud>=2.4.1"


import cv2;
import numpy as np
from watson_developer_cloud import VisualRecognitionV3




visual_recognition = VisualRecognitionV3('2018-03-19',iam_apikey='NZDOAFD7T4EozdftZmkBrQSilwj-E7kLiOO8YZ3AYRUZ')

X_DIMENSION = 288
Y_DIMENSION = 382
black_image = np.zeros((X_DIMENSION, Y_DIMENSION))


def predict(images_file):
  try:
    classes = visual_recognition.classify(images_file,threshold='0.6',classifier_ids='Asl50_848078132').get_result()
    var=classes["images"][0]["classifiers"][0]["classes"][0]["class"]
    print("predicted class is ",var)
    black_image = np.zeros((X_DIMENSION, Y_DIMENSION))
    cv2.putText(black_image,var, (100,100), 0, 2, 100)
    cv2.imshow("Result",black_image)
  except:
    print("something went wrong")




while True:
  
  cam_capture = cv2.VideoCapture(0)
  _, image_frame = cam_capture.read()

  cv2.imshow("Preview",image_frame);
  

  if cv2.waitKey(25) & 0xFF == ord('r'):
    cv2.imwrite("frame1.jpg",image_frame)
    with open('frame1.jpg', 'rb') as images_file:
      predict(images_file)

  
  
  if cv2.waitKey(25) & 0xFF == ord('q'):
    cv2.destroyAllWindows()
    break











# with open('test.jpg', 'rb') as images_file:
#     classes = visual_recognition.classify(images_file,threshold='0.6',classifier_ids='Asl50_848078132').get_result()
# var=classes["images"][0]["classifiers"][0]["classes"][0]["class"]
# print("predicted class is ",var)



"""
{
  "images": [
    {
      "classifiers": [
        {
          "classifier_id": "A2J_1734476288",
          "name": "A2J",
          "classes": [
            {
              "class": "A",
              "score": 0.739
            }
          ]
        }
      ],
      "image": "test.jpg"
    }
  ],
  "images_processed": 1,
  "custom_classes": 10
}
"""