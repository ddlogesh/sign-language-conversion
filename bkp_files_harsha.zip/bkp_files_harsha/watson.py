# dependencies
# pip install --upgrade "watson-developer-cloud>=2.4.1"

from watson_developer_cloud import VisualRecognitionV3

visual_recognition = VisualRecognitionV3(
    version='2018-03-19',
    iam_apikey='SBtaTP0tMhL7JkZWvRHYSpxW5fQiSxFFIaaFGrhNpjF9'
)


visual_recognition = VisualRecognitionV3(
    '2018-03-19',
    iam_apikey='SBtaTP0tMhL7JkZWvRHYSpxW5fQiSxFFIaaFGrhNpjF9')


with open('test.jpg', 'rb') as images_file:
    classes = visual_recognition.classify(images_file,threshold='0.6',classifier_ids='A2J_1734476288').get_result()

print(classes)
print(type(classes))
var=classes["images"][0]["classifiers"][0]["classes"][0]["class"]
print("predicted class is ",var)



"""
{
  "images": [
    {
      "classifiers": [
        {
          "classifier_id": "A2J_1734476288",
          "name": "A2J",
          "classes": [
            {
              "class": "A",
              "score": 0.739
            }
          ]
        }
      ],
      "image": "test.jpg"
    }
  ],
  "images_processed": 1,
  "custom_classes": 10
}
"""