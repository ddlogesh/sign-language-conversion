import json

data ={
  "images": [
    {
      "classifiers": [
        {
          "classifier_id": "A2J_1734476288",
          "name": "A2J",
          "classes": [
            {
              "class": "A",
              "score": 0.739
            }
          ]
        }
      ],
      "image": "test.jpg"
    }
  ],
  "images_processed": 1,
  "custom_classes": 10
}
		

var=data["images"][0]["classifiers"][0]["classes"][0]["class"]
print(var)
print(type(var))

