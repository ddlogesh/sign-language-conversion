#cell 1
from tqdm import tqdm
def get_data(folder):
    X = []
    y = []
    for folderName in os.listdir(folder):
        if not folderName.startswith('.'):
          
            label=-1
         
          
            if folderName in ['A']:
                label = 1
            elif folderName in ['B']:
                label = 2
            elif folderName in ['C']:
                label = 3
            elif folderName in ['D']:
                label = 4
            elif folderName in ['E']:
                label = 5
            elif folderName in ['F']:
                label = 6
            elif folderName in ['G']:
                label = 7
            elif folderName in ['H']:
                label = 8
            elif folderName in ['I']:
                label = 9
            elif folderName in ['J']:
                label = 10
            elif folderName in ['K']:
                label = 11
            elif folderName in ['L']:
                label = 12
            elif folderName in ['M']:
                label = 13
            elif folderName in ['N']:
                label = 14
            elif folderName in ['O']:
                label = 15
            elif folderName in ['P']:
                label = 16
            elif folderName in ['Q']:
                label = 17
            elif folderName in ['R']:
                label = 18
            elif folderName in ['S']:
                label = 19
            elif folderName in ['T']:
                label = 20
            elif folderName in ['U']:
                label = 21
            elif folderName in ['V']:
                label = 22
            elif folderName in ['W']:
                label = 23
            elif folderName in ['X']:
                label = 24
            elif folderName in ['Y']:
                label = 25
            elif folderName in ['Z']:
                label = 26
            elif folderName in ['Zdel']:
                label = 27
            elif folderName in ['Zspace']:
                label = 28
              
                
            print("Folder -> ",folderName,label)    
            for image_filename in tqdm(os.listdir(folder + folderName)):
                img_file = cv2.imread(folder + folderName + '/' + image_filename)
                if img_file is not None:
                    img_file = skimage.transform.resize(img_file, (imageSize, imageSize, 3))
                    img_arr = np.asarray(img_file)
                    X.append(img_arr)
                    y.append(label)
    X = np.asarray(X)
    y = np.asarray(y)
    return X,y